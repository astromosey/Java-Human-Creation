
/**Human objects with basic measurements and organs that can engage in activities
altering many measurements and organ attributes
*/

public class Human {
	
//INSTANCE VARIABLES
	String name; 
	int age;
	double height;
	double weight;
	String hairStyle; 
	private Heart heart;
	private Brain brain;
	private RightLung rightLung;
	private LeftLung leftLung;
	private Liver liver;

	
	public Human(String name, int age, double height, double weight, String hairStyle){ 
		this.name = name;
		this.age = age;
		this.height = height;
		this.weight = weight;
		this.hairStyle = hairStyle;
		heart = new Heart();
		brain = new Brain();
		rightLung = new RightLung();
		leftLung = new LeftLung();
		liver = new Liver();
	}
	
// MUTATORS
	// INSTEAD OF INCREASE/DECREASE WEIGHT
	/** sets weight of human
	 * @param weight Weight in pounds as floating number
	*/
	public void setWeight(double weight) {
		this.weight = weight;
	}

	/** makes human object run:
	 *  increases: heart rate, breathing rate, lung quality
	 *  decreases: weight
	 *  Weight Calculation: calories burned per mile based on weight, converted into pounds
	 * @param miles Floating point representation of distance ran in miles
	 */
	public void run(double miles) {
		heart.setRate(heart.getRate() + 40);
		rightLung.setRate(rightLung.getRate() + 20);
		rightLung.setQuality(rightLung.getQuality() + 0.5*miles); 
		leftLung.setRate(leftLung.getRate() + 20);
		leftLung.setQuality(leftLung.getQuality() + 0.5*miles);
		this.setWeight(this.getWeight() - (this.weight*(miles*0.75))/3500);
	}
	
	/** makes human rest from run activity, 
	 * brings heart rate and breathing rate back to resting levels
	 */
	public void runRest() {
		heart.setRate(heart.getRate() - 40);
		rightLung.setRate(rightLung.getRate() -20);
		leftLung.setRate(leftLung.getRate() -20);
	}
		
	/** makes human object walk: 
	 * increases: heart rate, breathing rate, lung quality
	 * decreases: weight
	 * Weight Calculation: calories burned per mile based on weight, converted into pounds
	 * @param miles Floating point representation of distance walked in miles
	 */
	public void walk(double miles) {
		heart.setRate(heart.getRate() + 20);
		rightLung.setRate(rightLung.getRate() + 5);                    
		rightLung.setQuality(rightLung.getQuality() + 0.25*miles);
		leftLung.setRate(leftLung.getRate() + 5);
		leftLung.setQuality(leftLung.getQuality() + 0.25*miles);
		this.setWeight(this.getWeight() - (this.weight*(miles*0.5))/3500);	
	}
	
	/** makes human rest from walk activity
	 * brings heart rate and breathing rate back to resting levels
	 */
	public void walkRest() {
		heart.setRate(heart.getRate() -20);
		rightLung.setRate(rightLung.getRate() - 5);
		leftLung.setRate(leftLung.getRate() - 5);
	}
	
	/** makes human object eat, calorie consumption
	 * @param calories Whole number amount of calories consumed
	 */
	public void eat(int calories) {
		this.setWeight(this.getWeight() + (calories/3500));
	}
	
	/** makes human object sleep
	 * decreases: heart rate, breathing rate, brain activity rate, weight 
	 * Weight Calculation: average sedentary calories burned in a day, converted into pounds
	 */
	public void sleep() {   
		heart.setRate(heart.getRate() - 20);
		rightLung.setRate(rightLung.getRate() - 5);
		leftLung.setRate(leftLung.getRate() - 5);
		brain.setRate(brain.getRate() - 10);  
		this.setWeight(this.getWeight() - (0.57));
	}
	
	/** makes human wake up, brings brain activity rate, heart rate, and breathing rate 
	 * back to waking levels
	 */
	public void wakeUp() {
		brain.setRate(brain.getRate() + 10);
		rightLung.setRate(rightLung.getRate() + 5);
		leftLung.setRate(leftLung.getRate() + 5);
		heart.setRate((heart.getRate() + 20));
	}
	
	/** makes human sit, decreasing heart rate
	 */
	public void sit() {
		heart.setRate(heart.getRate() - 10);
	}
	
	/** changes human's hair style 
	 * @param hair String establishing new hair style from haircut
	 */
	public void haircut(String hair) {
		this.hairStyle = hair;
	}
	
	/** makes human drink booze
	 *  increases: liver processing rate
	 *  decreases: liver quality and brain quality
	 */
	public void booze() {
		liver.setRate(liver.getRate() + 15);   
		liver.setQuality(liver.getQuality() - 1);     
		brain.setQuality(brain.getQuality() - 20);
	}
	
	/** human break from drinking booze, brings liver processing rate and brain quality
	 * back to sober levels
	 */
	public void boozeRest(){ 
		liver.setRate(liver.getRate() - 15);
		brain.setQuality(brain.getQuality() + 19);	
	}
	
	/** makes human smoke, decreasing lung and heart quality
	 */
	public void smoke() {
		rightLung.setQuality(rightLung.getQuality() - 1); 
		leftLung.setQuality(leftLung.getQuality() - 1);
		heart.setQuality(heart.getQuality() - 2);
	}
	

//ACCESSORS	
	
	/** gets human age
	 * @return age Integer representation of age
	 */
	public int getAge() {
		return age;
	}
	
	/** gets human's height
	 * @return height Double representation of human height in feet
	 */
	public double getHeight() {
		return height;
	}

	/** gets weight of human
	 * @return weight Floating point representation of human weight in pounds
	*/
	public double getWeight() {
		return weight;
	}
	
	/** returns hair style
	 * @return hairStyle String stating person's current hair style
	 */
	public String getHairStyle() {
		return hairStyle;
	}
	
//HEART GETTERS	
	/** returns heart rate
	 * @return heartRate Integer representing heart rate (BPM)
	 */
	public int getHeartRate() {
		return heart.getRate();
	}
	
	/** returns heart quality
	 * @return heartQuality Double representation of heart quality (in percent)
	 */
	public double getHeartQuality() {
		return heart.getQuality();
	}
	
//LUNG GETTERS
	/** returns lungs rate
	 * @return breathingRate Integer representing breaths per minute
	 */
	public int getRightLungRate() {
		return rightLung.getRate();
	}
	
	public int getLeftLungRate() {
		
		return leftLung.getRate();
	}
	/** returns lungs quality
	 * @return lungsQuality Double representation of lungs quality (in percent)
	 */
	public double getRightLungQuality() {
		
		return rightLung.getQuality();
	}
	
	public double getLeftLungQuality() {
		
		return leftLung.getQuality();
	}
	
//LIVER GETTERS
	/** returns liver processing rate
	 * @return processingRate Integer representing rate of liver processing
	 */
	public int getLiverRate() {
		return liver.getRate();
	}
	
	/** returns liver quality
	 * @return liverQuality Double representation of liver quality (in percent) 
	 */
	public double getLiverQuality() {
		return liver.getQuality();
	}
	
//BRAIN GETTERS
	/** returns brain activity rate
	 * @return brainActivityRate Integer representing rate of brain activity (beta wave cycles/second)
	 */
	public int getBrainRate() {
		return brain.getRate();
	}
	
	/** returns brain quality
	 * @return brainQuality Double representation of brain quality (in percent) 
	 */
	public double getBrainQuality() {
		return brain.getQuality();
	}

	public void checkVitals() {
		System.out.println(name + "'s Brain Activity Rate is: " + brain.getRate() + " beta wave cycles per second");
		System.out.println(name + "'s Brain Quality is: " + brain.getQuality() + "%"); 
		System.out.println(name + "'s Heart Rate is: " + heart.getRate() + " beats per minute");
		System.out.println(name + "'s Heart Quality is: " + heart.getQuality() + "%");                                   
		System.out.println(name + "'s Right Lung Breathing Rate is: " + rightLung.getRate() + " breaths per minute");
		System.out.println(name + "'s Left Lung Breathing Rate is: " + leftLung.getRate() + " breaths per minute");
		System.out.println(name + "'s Right Lung Quality is: " + rightLung.getQuality() + "%"); 
		System.out.println(name + "'s Left Lung Quality is: " + leftLung.getQuality() + "%");
		System.out.println(name + "'s Liver Processing Rate is: " + liver.getRate());
		System.out.println(name + "'s Liver Quality is: " + liver.getQuality() + "%");	
	}
	
} 