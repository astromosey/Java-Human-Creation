
/** Heart subclass of Human class that have attributes
 * altered by human activities
 */
public class Brain {

//INSTANCE VARIABLES
	private int brainActivityRate;
	private double brainQuality;
	
	public Brain() {
		brainActivityRate = 30; // avg beta wave cycles/second
		brainQuality = 100;
	}

//MUTATORS	
	/** sets brain activity rate
	 * @param rate Integer representing rate of brain activity (beta wave cycles/second)
	*/
	public void setRate(int rate) {
		this.brainActivityRate = rate;
	}
	
	/** sets brain quality
	 * @param Quality Double representation of brain quality (in percent)
	*/
	public void setQuality(double Quality) {
		this.brainQuality = Quality;
	}

//ACCESSORS	
	/** returns brain activity rate
	 * @return brainActivityRate Integer representing rate of brain activity (beta wave cycles/second)
	 */
	public int getRate() {
		return brainActivityRate;   
	}
	
	/** returns brain quality
	 * @return brainQuality Double representation of liver quality (in percent) 
	 */
	public double getQuality() {
		return brainQuality;
	}	
	
}