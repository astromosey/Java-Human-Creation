
/** Lungs subclass of Human class that have attributes
 * altered by human activities
 */
public class RightLung {
	
//INSTANCE VARIABLES
	private int breathingRate;
	private double lungQuality;
	
	public RightLung() { //left lung needs to have lower quality
		breathingRate = 15; //avg breaths per min
	    lungQuality = 100;
	}

//MUTATORS
	/** sets lungs rate
	 * @param rate Integer representing breaths per minute
	 */	
	public void setRate(int rate) {		
	   this.breathingRate = rate;
	}	
	
	/** sets lungs quality
	 * @param quality Double representation of lungs quality (in percent)
	 */
	public void setQuality(double quality) {
		this.lungQuality = quality;
	}
	
//ACCESSORS
	/** returns lungs rate
	 * @return breathingRate Integer representing breaths per minute
	 */
	public int getRate() {
		return breathingRate;
	}
	
	/** returns lungs quality
	 * @return lungsQuality Double representation of lungs quality (in percent)
	 */
	public double getQuality() {
		return lungQuality;
	}
	
}