
public class Tester {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Human erin = new Human("Erin", 21, 5.5, 120, "long");
		
		System.out.println("Erin Base Vitals:");
		erin.checkVitals();
		System.out.println("Erin's Weight:" +erin.getWeight());

		erin.run(1);
		System.out.println();
		System.out.println("Erin After Run:");
		erin.checkVitals();
		System.out.println("Erin's weight after run:" +erin.getWeight());
		
		erin.runRest();
		System.out.println();
		System.out.println("Erin After Run Rest:");
		erin.checkVitals();
		
		erin.walk(1);
		System.out.println();
		System.out.println("Erin After Walk:");
		erin.checkVitals();
		System.out.println("Erin's Weight After Walk:" +erin.getWeight());
		
		erin.walkRest();
		System.out.println();
		System.out.println("Erin After Walk Rest:");
		erin.checkVitals();

		erin.eat(3500);
		System.out.println();
		System.out.println("Erin After Eating Dinner:");
		erin.checkVitals();
		System.out.println("Erin's Weight After Eating:" +erin.getWeight());
		
		erin.sleep();
		System.out.println();
		System.out.println("Erin After Sleeping:");
		erin.checkVitals();
		System.out.println("Erin's Weight After Sleeping:" +erin.getWeight());
		
		erin.wakeUp();
		System.out.println();
		System.out.println("Erin After Waking Up:");
		erin.checkVitals();
		
		erin.sit();
		System.out.println();
		System.out.println("Erin After Sitting:");
		erin.checkVitals();

		erin.haircut("short");
		System.out.println();
		System.out.println("Erin's Hair After Haircut: " +erin.getHairStyle());
		
		erin.booze();
		System.out.println();
		System.out.println("Erin After Drinking:");
		erin.checkVitals();

		erin.boozeRest();
		System.out.println();
		System.out.println("Erin After Taking A Break From Drinking:");
		erin.checkVitals();
		
		erin.smoke();
		System.out.println();
		System.out.println("Erin After Smoking A Cigarette:");
		erin.checkVitals();

	}

}
