
/** Heart subclass of Human class that have attributes
 * altered by human activities
 */
public class Heart {

//INSTANCE VARIABLES
	private int heartRate;
	private double heartQuality;
	
	
	public Heart() {
		heartRate = 80;
		heartQuality = 100;
	}
	
//MUTATORS
	/** returns heart rate
	 * @param rate Integer representing heart rate (BPM)
	 */
	public void setRate(int rate) {	
		this.heartRate = rate;
	}
	
	/** returns heart quality
	 * @param quality Double representation of heart quality (in percent)
	 */
	public void setQuality(double quality) {	
		this.heartQuality = quality;
	}
	
//ACCESSORS
	/** returns heart rate
	 * @return heartRate Integer representing heart rate (BPM)
	 */
	public int getRate() {
		return heartRate;
	}
	
	/** returns heart quality
	 * @return heartQuality Double representation of heart quality (in percent)
	 */
	public double getQuality() {
		return heartQuality;
	}	

}
