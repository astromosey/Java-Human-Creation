
/** Liver subclass of Human class that have attributes
 * altered by human activities
 */
public class Liver {
	
//INSTANCE VARIABLES
	private int processingRate;
	private double liverQuality;
	
	
	public Liver() {
		processingRate = 80; 
		liverQuality = 100;
	}
	
//MUTATORS
	/** sets liver processing rate
	 * @param rate Integer representing rate of liver processing
	 */
	public void setRate(int rate) {
		this.processingRate = rate;
	}
	
	/** sets liver quality
	 * @return quality Double representation of liver quality (in percent) 
	 */
	public void setQuality(double quality) {
		this.liverQuality = quality;
	}
	
	
//ACCESSORS
	/** returns liver processing rate
	 * @return processingRate Integer representing rate of liver processing
	 */
	public int getRate() {
		return processingRate;
	}
	
	/** returns liver quality
	 * @return liverQuality Double representation of liver quality (in percent) 
	 */
	public double getQuality() {
		return liverQuality;
	}
	
}